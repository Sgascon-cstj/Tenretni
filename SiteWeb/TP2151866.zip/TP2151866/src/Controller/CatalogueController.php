<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Request;
use Doctrine\Persistence\ManagerRegistry;

use App\Entity\Produit;
use App\Entity\Categorie;

class CatalogueController extends AbstractController
{
    private $em = null;

    #[Route('/', name: 'app_catalogue')]
    public function index(Request $request, ManagerRegistry $doctrine): Response
    {
        $this->em = $doctrine->getManager();

        $idCategorie = $request->query->get('categorie');
        $searchField = $request->request->get('search_field');
        $cars = $this->retrieve($idCategorie, $searchField);
        $categories = $this->retrieveCategorie();
      
        
        return $this->render('catalogue/index.html.twig', [
            'controller_name' => 'CatalogueController', 'cars' => $cars, 'categories' => $categories,
        ]);
    }
    private function retrieve($idCategorie, $searchField) {
        return $this->em->getRepository(Produit::class)->findWithCriteria($idCategorie, $searchField);         
    }
    private function retrieveCategorie(){
        return $this->em->getRepository(Categorie::class)->findAll();        
    }

    #[Route('/produit/{idProduit}', name:'produit_modal')]
    public function infoModal($idProduit, Request $request, ManagerRegistry $doctrine): Response {
   

        $this->em = $doctrine->getManager();

        $car = $this->em->getRepository(Produit::class)->find($idProduit);

        return $this->render('catalogue/produit.modal.twig', ['car' => $car]);

    }
}
